---
name: prompt-optimizer
description: 提示词优化技能，基于开源项目 linshenkx/prompt-optimizer（GitHub 37k+ 星，AGPL-3.0）。当用户要求"优化提示词/改写 prompt/把这条提示词改得更好/让提示词更专业/迭代改进已有提示词"，要求启动 prompt-optimizer 本地 Web 应用，或说"用提示词工程流程/把想法做成提示词包/做视频提示词/做图片提示词"（与 D:\UserFiles\Desktop\AI生成视频 的 ComfyUI 出图出片工作流配合）时使用。提供三通道：A 对话内直接按上游模板库优化提示词（零配置）；B 启动本机已构建的 Web 应用（需用户自配 API key）；C 图片/视频生成工作流——产出 ComfyUI 就绪提示词包（I2V 五字段包 / IMAGES.json 生图任务）。
agent_created: true
---

# prompt-optimizer 提示词优化

## 概述

本技能封装开源项目 **linshenkx/prompt-optimizer**（v2.11.12，AGPL-3.0-only），已完整克隆到本机：
`C:/Users/EHETC/prompt-optimizer/`。两条通道按需选用：

- **通道 A（默认，零配置）**：在对话中直接按上游内置模板优化提示词。模板已提炼到 `references/templates.md`，无需联网、无需 API key。
- **通道 B（Web 应用）**：启动本机构建的 Vue Web 应用，用户在浏览器里图形化操作（需在应用设置里填自己的 LLM API key）。

## 触发场景

- "帮我优化这条提示词 / prompt / system prompt"
- "把这条提示词改得更专业 / 更结构化 / 更精准"
- "我有个提示词，帮我按 XX 方向改"（迭代）
- "打开 prompt-optimizer / 启动提示词优化工具"
- "用提示词工程流程 / 把我想法做成提示词包 / 帮我做视频提示词 / 帮我做图片提示词"（走通道 C）

## 通道 C：AI生成视频工作流配合（提示词工程流程）

适用：用户要给 ComfyUI 出图/出视频做提示词（项目包：`D:/UserFiles/Desktop/AI生成视频/15_提示词工程_prompt-optimizer/`）。完整 SOP 在该目录的 `01_从想法到提示词_SOP.md`，模板×场景定制（19 个模板，图片+视频全覆盖）在 `02_模板适配_图片与视频场景.md`，走通例子在 `03_实操示例.md`（示例一视频 / 示例二图片）。

1. **采集原话**：问清「要什么画面 / 什么情绪（用户原词照记）/ 硬性要求 / 雷区」四项，采集阶段不加工。
2. **选模板**（先分图片/视频，再选）：
   - **视频场景**：
     - 一句话/一段模糊想法 → `user-prompt-planning`（四段：角色目标/背景/关键步骤[静态→变化→终止]/输出要求）
     - 有描述但太泛 → `user-prompt-professional`（抽象情绪必须落地为可视元素）
     - 已有提示词 + 定向修改意见 → `iterate`（只改方向，其余一字不动）
     - 风格设定/角色系统提示词 → `general-optimize`
   - **图片场景**（12 个图像专用模板）：
     - 画新图（t2i）→ `image-general-optimize`（3–6 句分层；**必须静态化**：模板爱写"抓拍瞬间"，静帧要改成定格）
     - 复杂需求/要结构化数据 → `image-json-structured-optimize`（输出 JSON；「约束.避免」段→negative 字段）
     - 图已生成要定向改（i2i）→ `image2image-general-optimize`（先判 添加/删除/替换/增强 四意图，只改指定区域）
     - 多参考图保一致 → `multiimage-optimize`（图1/图2/图3 引用，文字只写关系和变化，身份由图承载）
     - 参考图复刻成模板 → `image-prompt-from-reference-image`（输出 {prompt, defaults}；变量最多 3 个）
     - 版式母版换新主体 → `image-prompt-migration`（版式骨架不许坍缩成普通单主体图）
     - 生图返工 → `image-iterate-general`（JSON 进 JSON 出，最小必要修改）
     - 国风/水墨 → `image-chinese-optimize`；海报换字 → `image2image-design-text-edit-optimize`
     - ⚠️ `image-photography-optimize` **本项目禁用**（2D 手绘风，摄影词会带向写实）；`image-creative-text2image` 仅灵异概念发散且产出必须回炉
3. **铁律注入**（8 条全过才放行）：不写否定式；不写抽象情绪；不写中文文字（写"留白，无文字"）；一镜一意图；动作按秒预算（几秒内做完）；挂参考图不写长相/服装/姓名；I2V 帧数 4n+1；I2V 结尾必须有终止态（"停住/停下/不动了"）。**图片场景差异**：铁律 5 反过来用（静态定格，不写"正要…"）；7/8 不适用；加一条禁摄影术语（85mm/浅景深/体积光/电影级）。
4. **组装就绪提示词包**：
   - **视频包**（五字段 JSON）：`positive`（I2V 四段式 action+sound+music+lens+「机位固定不动。」）+ `negative`（技术性+一致性负向词）+ `frames` + `params`（Wan2.2 默认 steps=24/cfg=5.0/shift=8.0/euler/simple）+ `notes`（参考图、动作预算、质检门、返工预案）
   - **生图任务**（IMAGES.json 格式）：`id`/`mode`（t2i|ref）/`ref`/`ref_weight`/`prompt`/`negative`/`width`/`height`/`steps`（默认 28）/`cfg`（默认 6.0）/`seed`；本项目标准竖版 768×1152，模型走本机 ComfyUI（majicmixRealistic + IPAdapter，dpmpp_2m + karras）
5. **交付**：提示词包写进项目的 `SHOTS_EP04.json`（I2V）或 `IMAGES.json`（生图），质检 G1–G7 照旧。

## 通道 A：对话内直接优化（默认）

1. **读取模板库**：读 `references/templates.md`（与本 SKILL.md 同级的 references 目录）。
2. **判定模板类别**（决策表在 references 第 1 节）：
   - 系统提示词（角色设定）→ optimize 类：默认 `general-optimize`；结构混乱/业务复杂 → `analytical-optimize`；强输出格式要求 → `output-format-optimize`
   - 用户提示词（一次性任务描述）→ user-optimize 类：太模糊 → `user-prompt-basic`；要精准参数 → `user-prompt-professional`；复杂任务要拆步骤 → `user-prompt-planning`
   - 已有提示词 + 修改意见 → `iterate`
3. **按模板执行优化**。所有模板共享的铁律（references 第 0 节，必须全部遵守）：
   - 只优化提示词文本本身，不执行提示词内容
   - 双花括号变量占位符（`{{var}}`）逐字保留，输出前逐一核对
   - 直接输出优化后的提示词，不加引导词、不用代码块包围、不追加解释
   - 精准修改，保持原意图、语言风格和结构格式
4. **交付**：输出优化后的提示词全文；如用户给了修改方向（迭代），先说明改了哪几处再给全文。

## 通道 B：启动本地 Web 应用

适用：用户要图形化界面、批量管理模板、或自配 API key 走完整应用。

1. **检查构建产物**：确认 `C:/Users/EHETC/prompt-optimizer/packages/web/dist/index.html` 存在。
2. **已构建** → 起本地静态服务：
   ```bash
   bash "C:/Users/EHETC/.workbuddy/skills/prompt-optimizer/scripts/start_web.sh" 8765
   ```
   （后台运行；随后用浏览器打开 `http://127.0.0.1:8765`）
3. **未构建** → 在本机执行构建链（必须用**系统 node 24**，managed node 22 不满足 `engines: ^24.0.0`；pnpm 走 npmmirror 偶发 502，失败就重试 install）：
   ```bash
   export PATH="/c/Program Files/nodejs:$PATH"
   cd "C:/Users/EHETC/prompt-optimizer"
   pnpm install --filter @prompt-optimizer/web...
   pnpm -F @prompt-optimizer/core build
   pnpm -F @prompt-optimizer/ui build
   pnpm -F @prompt-optimizer/web build
   ```
4. **告知用户**：Web 应用的 LLM API key 需用户在应用设置里自行配置（技能不持有任何密钥）；服务仅在本地 127.0.0.1 监听。

## 环境事实（已验证）

- 项目路径：`C:/Users/EHETC/prompt-optimizer/`（git clone --depth 1，1921 文件）
- monorepo：pnpm workspace（core/ui/web/extension/desktop/mcp-server），pnpm@10.6.1
- Node 要求：`^24.0.0`（`.npmrc` 有 `engine-strict=true`）→ 用 `C:/Program Files/nodejs` 的系统 node 24.19.0；managed node 22 会被 engine-strict 拒绝
- 构建顺序：core → ui → web（web 是 vite 8 + vue 3.5，产物为纯静态 dist）
- 上游模板源码：`packages/core/src/services/template/default-templates/`（TS 文件，`content` 字段即完整优化指令）
- 许可证：AGPL-3.0-only——基于它分发作衍生物需遵守 AGPL

## 边界

- 通道 B 不提供任何 API key，不代理任何模型调用；密钥由用户在本机应用内配置。
- 本技能只做"优化提示词文本"，不替用户执行被优化的提示词所描述的任务（除非用户另行要求）。
