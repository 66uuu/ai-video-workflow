#!/usr/bin/env bash
# 启动 prompt-optimizer 本地 Web 应用（静态 dist + python http.server）
# 用法: start_web.sh [端口]   默认端口 8765
set -e

PROJECT="C:/Users/EHETC/prompt-optimizer"
DIST="$PROJECT/packages/web/dist"
PORT="${1:-8765}"
PY="C:/Users/EHETC/.workbuddy/binaries/python/envs/default/python.exe"

if [ ! -f "$DIST/index.html" ]; then
  echo "[错误] 未找到 $DIST/index.html —— Web 应用尚未构建。"
  echo "先执行构建链："
  echo "  cd \"$PROJECT\""
  echo "  pnpm install --filter @prompt-optimizer/web..."
  echo "  pnpm -F @prompt-optimizer/core build"
  echo "  pnpm -F @prompt-optimizer/ui build"
  echo "  pnpm -F @prompt-optimizer/web build"
  exit 1
fi

echo "prompt-optimizer Web 启动中: http://127.0.0.1:$PORT"
echo "（Ctrl+C 停止服务）"
cd "$DIST"
exec "$PY" -m http.server "$PORT" --bind 127.0.0.1
